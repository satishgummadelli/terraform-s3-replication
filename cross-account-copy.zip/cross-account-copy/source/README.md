# running exports jobs

aws rds start-export-task \
    --export-task-identifier my_snapshot_export \
    --source-arn arn:aws-cn:rds:Amazon_Region:123456789012:snapshot:snapshot_name \
    --s3-bucket-name my_export_bucket \
    --iam-role-arn iam_role \
    --kms-key-id master_key-source-account